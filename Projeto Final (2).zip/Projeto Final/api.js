const express = require('express');
const cors = require('cors');
const consulta = require('./database');


const app = express();

app.use(cors()); 
app.use(express.json());

app.get('/fornecedores', function(req, res) {
  consulta.query('SELECT * FROM fornecedores ORDER BY id', function(err, result) {
    if (err) return res.status(500).json({ error: err.message });
    res.json(result.rows);
  });
});


app.post('/fornecedores', function(req, res) {


const descricao = req.body.descricao;
const categoria = req.body.categoria;
const contato   = req.body.contato;
const nome_anunciante = req.body.nome_anunciante;
const cpf_cnpj  = req.body.cpf_cnpj;
const hora_inicio = req.body.hora_inicio;
const hora_fim  = req.body.hora_fim;
  
  const sql = `INSERT INTO fornecedores 
               (descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim) 
               VALUES ('${descricao}', '${categoria}', '${contato}', '${nome_anunciante}', '${cpf_cnpj}', '${hora_inicio}', '${hora_fim}') 
               RETURNING *`;
  
  consulta.query(sql, function(err, result) {
    if (err){
     
    }
      
    res.status(201).json(result.rows[0]);
  });
});

app.listen( 3000, function() {
  console.log('Servidor rodando na porta 3000');
});


