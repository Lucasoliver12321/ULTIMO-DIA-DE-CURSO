var todosFornecedores = [];

    function carregarFornecedores() {
      var container = document.getElementById('fornecedores-container');
      container.innerHTML = '<div class="loading">Carregando profissionais...</div>';

      fetch('http://localhost:3000/fornecedores') 
        .then(function (response) {
          return response.json();
        })
        .then(function (data) {
          todosFornecedores = data;
          var primeiros20 = data.slice(0, 20);
          mostrarFornecedores(primeiros20);
          configurarBusca();
        })
        .catch(function (error) {
          console.error('Erro ao carregar fornecedores:', error);
          container.innerHTML = '<div class="error">Erro ao carregar profissionais. Verifique se a API está rodando.</div>';
        });
    }

    function mostrarFornecedores(fornecedores) {
      var container = document.getElementById('fornecedores-container');
      container.innerHTML = '';

      if (!Array.isArray(fornecedores) || fornecedores.length === 0) {
        container.innerHTML = '<div class="empty">Nenhum profissional encontrado</div>';
        return;
      }

      for (const fornecedor of fornecedores) {
        var cartao = document.createElement('div');
        cartao.className = 'cartao-prestador';

        var categoria = fornecedor.categoria || 'Geral';
        var nome = fornecedor.nome_anunciante || 'Nome não informado';
        var descricao = fornecedor.descricao || 'Descrição não disponível';
        var contato = fornecedor.contato || 'Não informado';
        var horaInicio = fornecedor.hora_inicio || '--';
        var horaFim = fornecedor.hora_fim || '--';

        cartao.innerHTML = `
          <div class="cabecalho-cartao">
            <div class="etiqueta-prestador">${categoria}</div>
          </div>
          <h3 class="titulo-prestador">${nome}</h3>
          <p class="descricao-prestador">${descricao}</p>
          <div class="detalhes-prestador">
            <div class="info-contato"><strong>Contato:</strong> ${contato}</div>
            <div class="info-horario"><strong>Horário:</strong> ${horaInicio} às ${horaFim}</div>
          </div>
        `;

        var botao = document.createElement('button');
        botao.className = 'botao-contato-primario';
        botao.textContent = 'Entrar em Contato';
        (function (contatoAtual) {
          botao.onclick = function () {
            mostrarContato(contatoAtual);
          };
        })(contato);

        cartao.appendChild(botao);
        container.appendChild(cartao);
      }
    }

    function mostrarContato(contato) {
      if (contato && contato !== 'Não informado') {
        alert('Entre em contato: ' + contato);
      } else {
        alert('Informações de contato não disponíveis');
      }
    }

    function configurarBusca() {
      var campoBusca = document.getElementById('busca-nome');
      if (!campoBusca) return;

      campoBusca.addEventListener('input', function () {
        var textoBusca = this.value.toLowerCase();
        var filtrados = todosFornecedores.filter(function (f) {
          var nome = (f.nome_anunciante || '').toLowerCase();
          return nome.indexOf(textoBusca) !== -1;
        });
        mostrarFornecedores(filtrados);
      });
    }

    function configurarScrollSuave() {
      var links = document.querySelectorAll('a[href^="#"]');
      for (var i = 0; i < links.length; i++) {
        links[i].addEventListener('click', function (e) {
          e.preventDefault();
          var destinoId = this.getAttribute('href');
          var destinoEl = document.querySelector(destinoId);
          if (destinoEl) {
            destinoEl.scrollIntoView({ behavior: 'smooth' });
          }
        });
      }
    }

    document.addEventListener('DOMContentLoaded', function () {
      carregarFornecedores();
      configurarScrollSuave();
    });