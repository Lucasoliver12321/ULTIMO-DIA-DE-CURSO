const formulario = document.getElementById('fornecedores');

formulario.addEventListener('submit', function (evento) {
  evento.preventDefault(); // evita reload da página

  const dados = {
    nome_anunciante: document.getElementById('nome_anunciante').value,
    descricao: document.getElementById('descricao').value,
    categoria: document.getElementById('categoria').value,
    contato: document.getElementById('contato').value,
    cpf_cnpj: document.getElementById('cpf_cnpj').value,
    hora_inicio: document.getElementById('hora_inicio').value,
    hora_fim: document.getElementById('hora_fim').value,
    data_criacao: new Date().toISOString(), //  gera automático
    ativo: document.getElementById('ativo').checkedclear
  };

  fetch('http://localhost:3000/fornecedores', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  })
    .then(resposta => resposta.json())
    .then(resultado => {
      const mensagem = document.getElementById('mensagem');
      console.log(resultado);

      if (resultado && resultado.id) {
        mensagem.innerText = 'Fornecedor cadastrado com sucesso! ID: ' + resultado.id;
        mensagem.className = 'mensagem sucesso';

        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1200);
      } else {
        mensagem.innerText = 'Erro ao cadastrar: ' + (resultado.error || 'erro desconhecido');
        mensagem.className = 'mensagem erro';
      }
    })
    .catch(erro => {
      const mensagem = document.getElementById('mensagem');
      mensagem.innerText = 'Falha na conexão: ' + erro;
      mensagem.className = 'mensagem erro';
    });
});
